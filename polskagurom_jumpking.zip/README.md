<h3>Polska tabela runów w Jump King</h3>
Zrobiona za pomocą api strony speedrun.com
cos nie dziala, cos sie nie podoba - discord: zamordorr





